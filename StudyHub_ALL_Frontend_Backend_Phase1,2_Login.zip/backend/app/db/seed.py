"""Idempotent development seed for StudyHub Phase 1."""
from __future__ import annotations

from .database import Database, DEFAULT_DB_PATH
from ..security.password import hash_password


def seed(database: Database | None = None) -> None:
    database = database or Database(DEFAULT_DB_PATH)
    database.initialize()
    with database.connect() as conn:
        users = [
            ("StudyHub Admin", "admin@studyhub.local", hash_password("Admin123!"), "admin"),
            ("Nguyen Thanh Mai", "teacher@studyhub.local", hash_password("Teacher123!"), "teacher"),
            ("StudyHub Student", "student@studyhub.local", hash_password("Student123!"), "student"),
        ]
        for row in users:
            conn.execute(
                """INSERT INTO users(full_name,email,password_hash,role)
                   VALUES(?,?,?,?) ON CONFLICT(email) DO NOTHING""",
                row,
            )
        subjects = [
            ("ATTT", "Information Security", "Security fundamentals, cryptography and secure systems."),
            ("CSDL", "Database Systems", "Relational databases, SQL and database design."),
            ("RR", "Discrete Mathematics", "Logic, counting, probability and graph concepts."),
            ("LT", "Programming", "Programming fundamentals and practical software development."),
        ]
        for row in subjects:
            conn.execute(
                "INSERT INTO subjects(code,name,description) VALUES(?,?,?) ON CONFLICT(code) DO NOTHING",
                row,
            )
        plans = [
            ("Free", 0, 0, "Core StudyHub learning features", 10, 100),
            ("Standard", 49000, 470000, "AI Tutor and advanced learning tools", 100, 2048),
            ("Premium", 99000, 950000, "Deep personalization and advanced AI Tutor", None, 10240),
        ]
        for row in plans:
            conn.execute(
                """INSERT INTO plans(name,price_monthly,price_yearly,description,ai_daily_limit,storage_limit)
                   VALUES(?,?,?,?,?,?) ON CONFLICT(name) DO NOTHING""",
                row,
            )
        conn.commit()


if __name__ == "__main__":
    seed()
    print("StudyHub Phase 1 seed complete.")
