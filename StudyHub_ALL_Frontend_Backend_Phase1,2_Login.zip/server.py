#!/usr/bin/env python3
import json, os, re, secrets, sqlite3, hashlib, mimetypes
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from email.parser import BytesParser
from email.policy import default

from backend.app.db.database import Database
from backend.app.db.seed import seed as seed_database
from backend.app.security import authenticate, register as register_user, current_user, revoke_session, SESSION_COOKIE

ROOT=os.path.dirname(os.path.abspath(__file__)); WEB=os.path.join(ROOT,'web'); UP=os.path.join(ROOT,'uploads'); DB=os.environ.get('STUDYHUB_DB_PATH', os.path.join(ROOT,'data','studyhub.db'))
os.makedirs(UP,exist_ok=True); os.makedirs(os.path.dirname(DB),exist_ok=True)

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
 c.execute('PRAGMA foreign_keys = ON')
 c.execute('PRAGMA busy_timeout = 5000')
 return c

def init_db():
 Database(DB).initialize()
 seed_database(Database(DB))

def cookie_value(handler, name):
    raw = handler.headers.get('Cookie', '')
    for item in raw.split(';'):
        key, sep, value = item.strip().partition('=')
        if sep and key == name:
            return value
    return None

def user_from(handler):
    token = cookie_value(handler, SESSION_COOKIE)
    with db() as c:
        return current_user(c, token)

def session_cookie(token, max_age=7 * 24 * 60 * 60):
    return f'{SESSION_COOKIE}={token}; Path=/; Max-Age={max_age}; HttpOnly; SameSite=Lax'

class H(BaseHTTPRequestHandler):
 server_version='StudyHub/1.0'
 def send(self,status=200,body=b'',ctype='application/json',headers=None):
  self.send_response(status); self.send_header('Content-Type',ctype); self.send_header('Cache-Control','no-store');
  if headers:
   for k,v in headers.items(): self.send_header(k,v)
  self.end_headers(); self.wfile.write(body)
 def json(self,obj,status=200,headers=None): self.send(status,json.dumps(obj,ensure_ascii=False).encode(),headers=headers)
 def body(self):
  n=int(self.headers.get('Content-Length','0')); return self.rfile.read(n)
 def do_GET(self):
  p=urlparse(self.path); path=p.path
  if path in ('/api/me','/api/auth/me'): return self.json({'user':user_from(self)})
  if path=='/api/subjects':
   c=db(); rows=[dict(r) for r in c.execute('SELECT * FROM subjects ORDER BY name')]; c.close(); return self.json(rows)
  if path=='/api/documents':
   qs=parse_qs(p.query); q=qs.get('q',[''])[0]; sub=qs.get('subject',[''])[0]; c=db(); sql='SELECT d.*, d.original_filename AS file_name, d.storage_path AS file_path, d.uploaded_by AS uploader_id, s.code subject_code,s.name subject_name,u.full_name AS uploader FROM documents d JOIN subjects s ON s.id=d.subject_id JOIN users u ON u.id=d.uploaded_by WHERE 1=1'; args=[]
   if q: sql+=' AND (d.title LIKE ? OR d.description LIKE ?)'; args += [f'%{q}%',f'%{q}%']
   if sub: sql+=' AND s.code=?'; args.append(sub)
   sql+=' ORDER BY d.created_at DESC'; rows=[dict(r) for r in c.execute(sql,args)]; c.close(); return self.json(rows)
  m=re.fullmatch(r'/api/documents/(\d+)',path)
  if m:
   c=db(); r=c.execute('SELECT d.*, d.original_filename AS file_name, d.storage_path AS file_path, d.uploaded_by AS uploader_id, s.code subject_code,s.name subject_name,u.full_name AS uploader FROM documents d JOIN subjects s ON s.id=d.subject_id JOIN users u ON u.id=d.uploaded_by WHERE d.id=?',(m.group(1),)).fetchone(); c.close(); return self.json(dict(r) if r else {'error':'not found'},200 if r else 404)
  m=re.fullmatch(r'/download/(\d+)',path)
  if m:
   c=db(); r=c.execute('SELECT * FROM documents WHERE id=?',(m.group(1),)).fetchone();
   if not r or not r['storage_path']: c.close(); return self.json({'error':'document has no physical file'},404)
   rel=r['storage_path']
   fp=rel if os.path.isabs(rel) else os.path.join(ROOT, rel)
   fp=os.path.normpath(fp)
   try:
    inside = os.path.commonpath([ROOT, fp]) == ROOT
   except ValueError:
    inside = False
   if not inside:
    c.close(); return self.json({'error':'invalid file path'},400)
   if not os.path.exists(fp):
    c.close(); return self.json({'error':'file missing'},404)
   c.execute('UPDATE documents SET downloads=downloads+1 WHERE id=?',(m.group(1),)); c.commit(); c.close()
   data=open(fp,'rb').read(); return self.send(200,data,mimetypes.guess_type(fp)[0] or 'application/octet-stream',{'Content-Disposition':f'attachment; filename="{r["original_filename"]}"'})
  if path.startswith('/api/'):
   return self.json({'error':'not found'},404)
  fp=os.path.join(WEB,'index.html' if path=='/' else path.lstrip('/'))
  if not os.path.isfile(fp): return self.json({'error':'not found'},404)
  ext=os.path.splitext(fp)[1]; ct={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.svg':'image/svg+xml'}.get(ext,'application/octet-stream'); return self.send(200,open(fp,'rb').read(),ct)
 def do_POST(self):
  p=urlparse(self.path); path=p.path; data=self.body();
  if path in ('/api/login','/api/auth/login'):
   try:
    x=json.loads(data or '{}')
   except json.JSONDecodeError:
    return self.json({'error':'Dữ liệu đăng nhập không hợp lệ'},400)
   email=x.get('email','')
   password=x.get('password','')
   if not isinstance(email,str) or not isinstance(password,str) or not email.strip() or not password:
    return self.json({'error':'Vui lòng nhập email và mật khẩu'},400)
   with db() as c:
    result, error = authenticate(c, email, password)
   if error:
    return self.json({'error':error},403 if error == 'Tài khoản đang bị khóa' else 401)
   user, token, expires_at = result
   return self.json({'user':user,'expires_at':expires_at},200,{'Set-Cookie':session_cookie(token)})
  if path in ('/api/logout','/api/auth/logout'):
   token=cookie_value(self, SESSION_COOKIE)
   with db() as c:
    revoke_session(c, token)
   return self.json({'ok':True},200,{'Set-Cookie':session_cookie('',0)})
  if path in ('/api/register','/api/auth/register'):
   try:
    x=json.loads(data or '{}')
   except json.JSONDecodeError:
    return self.json({'error':'Dữ liệu đăng ký không hợp lệ'},400)
   name=x.get('name',''); email=x.get('email',''); pw=x.get('password','')
   if not all(isinstance(v,str) for v in (name,email,pw)):
    return self.json({'error':'Dữ liệu đăng ký không hợp lệ'},400)
   with db() as c:
    try:
     result, error = register_user(c, name, email, pw)
    except sqlite3.IntegrityError:
     result, error = None, 'Email đã tồn tại'
   if error:
    return self.json({'error':error},400)
   user, token, expires_at = result
   return self.json({'ok':True,'user':user,'expires_at':expires_at},201,{'Set-Cookie':session_cookie(token)})
  if path=='/api/upload':
   u=user_from(self)
   if not u or u['role'] not in ('teacher','admin'): return self.json({'error':'Bạn không có quyền upload'},403)
   ctype=self.headers.get('Content-Type',''); m=re.search(r'boundary=(.+)',ctype)
   if not m:return self.json({'error':'multipart form required'},400)
   msg=BytesParser(policy=default).parsebytes(b'Content-Type: '+ctype.encode()+b'\r\n\r\n'+data)
   fields={}; filepart=None
   for part in msg.iter_parts():
    disp=part.get('Content-Disposition',''); name=re.search(r'name="([^"]+)"',disp); filename=re.search(r'filename="([^"]*)"',disp)
    if not name:continue
    if filename and filename.group(1): filepart=(filename.group(1),part.get_payload(decode=True) or b'')
    else: fields[name.group(1)]=(part.get_payload(decode=True) or b'').decode(errors='ignore')
   if not filepart:return self.json({'error':'Chưa chọn file'},400)
   title=fields.get('title','').strip(); sid=fields.get('subject_id','')
   if not title or not sid:return self.json({'error':'Thiếu tiêu đề hoặc môn học'},400)
   try:
    subject_id=int(sid)
   except ValueError:
    return self.json({'error':'Môn học không hợp lệ'},400)
   c=db(); subject=c.execute('SELECT id FROM subjects WHERE id=?',(subject_id,)).fetchone()
   if not subject:
    c.close(); return self.json({'error':'Môn học không tồn tại'},400)
   safe=re.sub(r'[^A-Za-z0-9._-]','_',filepart[0]); stored=f'{secrets.token_hex(8)}_{safe}'
   target=os.path.join(UP,stored)
   with open(target,'wb') as fh: fh.write(filepart[1])
   ext=os.path.splitext(filepart[0])[1].lower().lstrip('.') or 'unknown'
   mime={'.pdf':'application/pdf','.txt':'text/plain','.doc':'application/msword','.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','.ppt':'application/vnd.ms-powerpoint','.pptx':'application/vnd.openxmlformats-officedocument.presentationml.presentation'}.get(os.path.splitext(filepart[0])[1].lower(),'application/octet-stream')
   c.execute('INSERT INTO documents(title,description,original_filename,storage_filename,file_type,mime_type,file_size,storage_path,status,subject_id,uploaded_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(title,fields.get('description',''),filepart[0],stored,ext,mime,len(filepart[1]),os.path.join('uploads',stored),'ready',subject_id,u['id']))
   c.commit(); document_id=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.close(); return self.json({'ok':True,'document_id':document_id,'status':'ready'},201)
  return self.json({'error':'not found'},404)

class StudyHubHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True

def main():
    init_db()
    port=int(os.environ.get('STUDYHUB_PORT','5000'))
    print(f'StudyHub running at http://127.0.0.1:{port}')
    with StudyHubHTTPServer(('127.0.0.1', port), H) as server:
        server.serve_forever()
if __name__=='__main__':main()
