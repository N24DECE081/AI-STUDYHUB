import os, subprocess, sys, time, urllib.request, urllib.error, tempfile
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class ServerIntegrationTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.port = 8765
        cls.tmp = tempfile.TemporaryDirectory()
        env = os.environ.copy()
        env['STUDYHUB_PORT'] = str(cls.port)
        env['STUDYHUB_DB_PATH'] = str(Path(cls.tmp.name) / 'integration.db')
        cls.proc = subprocess.Popen([sys.executable, str(ROOT/'run.py')], cwd=ROOT, env=env,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        deadline=time.time()+5
        while time.time()<deadline:
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{cls.port}/', timeout=0.5): break
            except Exception: time.sleep(0.1)
        else:
            out=cls.proc.stdout.read() if cls.proc.stdout else ''
            raise RuntimeError('server did not start: '+out)
    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate(); cls.proc.wait(timeout=5); cls.tmp.cleanup()
    def get(self,path):
        with urllib.request.urlopen(f'http://127.0.0.1:{self.port}{path}', timeout=2) as r:
            return r.status, r.headers.get_content_type(), r.read()
    def test_real_http_assets_and_api(self):
        status,ctype,body=self.get('/')
        self.assertEqual(status,200); self.assertEqual(ctype,'text/html'); self.assertIn(b'StudyHub',body)
        status,ctype,body=self.get('/styles.css')
        self.assertEqual(status,200); self.assertEqual(ctype,'text/css'); self.assertIn(b'--red',body)
        status,ctype,body=self.get('/app.js')
        self.assertEqual(status,200); self.assertEqual(ctype,'application/javascript'); self.assertIn(b'function',body)
        status,ctype,body=self.get('/api/subjects')
        self.assertEqual(status,200); self.assertEqual(ctype,'application/json'); self.assertIn(b'ATTT',body)
        status,ctype,body=self.get('/api/documents')
        self.assertEqual(status,200); self.assertEqual(ctype,'application/json')

    def test_login_session_and_no_password_leak(self):
        import json
        payload=json.dumps({'email':'teacher@studyhub.local','password':'Teacher123!'}).encode()
        req=urllib.request.Request(f'http://127.0.0.1:{self.port}/api/login', data=payload, headers={'Content-Type':'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=2) as r:
            body=r.read(); cookie=r.headers.get('Set-Cookie')
        self.assertEqual(r.status,200)
        self.assertIsNotNone(cookie)
        self.assertNotIn(b'password',body)
        req=urllib.request.Request(f'http://127.0.0.1:{self.port}/api/me', headers={'Cookie':cookie.split(';',1)[0]})
        with urllib.request.urlopen(req, timeout=2) as r:
            me=json.loads(r.read())
        self.assertEqual(me['user']['role'],'teacher')
        self.assertNotIn('password_hash', me['user'])


    def test_register_logout_and_session_persistence(self):
        import json
        email=f'integration_student_{time.time_ns()}@example.com'
        payload=json.dumps({'name':'Integration Student','email':email,'password':'StrongPass123!'}).encode()
        req=urllib.request.Request(f'http://127.0.0.1:{self.port}/api/register', data=payload, headers={'Content-Type':'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=2) as r:
            body=json.loads(r.read()); cookie=r.headers.get('Set-Cookie')
        self.assertEqual(r.status,201)
        self.assertIsNotNone(cookie)
        self.assertEqual(body['user']['email'], email)
        self.assertNotIn('password_hash', body['user'])
        req=urllib.request.Request(f'http://127.0.0.1:{self.port}/api/me', headers={'Cookie':cookie.split(';',1)[0]})
        with urllib.request.urlopen(req, timeout=2) as r:
            me=json.loads(r.read())
        self.assertEqual(me['user']['email'], email)
        req=urllib.request.Request(f'http://127.0.0.1:{self.port}/api/logout', data=b'{}', headers={'Cookie':cookie.split(';',1)[0], 'Content-Type':'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=2) as r:
            logout=json.loads(r.read())
        self.assertTrue(logout['ok'])
        req=urllib.request.Request(f'http://127.0.0.1:{self.port}/api/me', headers={'Cookie':cookie.split(';',1)[0]})
        with urllib.request.urlopen(req, timeout=2) as r:
            me=json.loads(r.read())
        self.assertIsNone(me['user'])

    def test_missing_asset_is_404(self):
        with self.assertRaises(urllib.error.HTTPError) as cm:
            self.get('/does-not-exist.css')
        self.assertEqual(cm.exception.code,404)

if __name__=='__main__': unittest.main()
