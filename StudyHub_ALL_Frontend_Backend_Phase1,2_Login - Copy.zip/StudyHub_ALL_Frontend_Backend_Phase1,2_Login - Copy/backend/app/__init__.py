"""StudyHub backend application package."""
